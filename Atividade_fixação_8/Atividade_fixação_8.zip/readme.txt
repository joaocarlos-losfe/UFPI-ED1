Atividade feita em dupla
Vitor José Ferreira dos Santos de Santana e João Carlos de Moura Fé

Na terceira questão, em caso de erro na compilação, execute:
	gcc 3.c -o 3 -lm
foi usado a biblioteca math.h para resolver o exercício
